globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/0MAsF4BEf1hiwkPXa9ive/_buildManifest.js",
    "static/0MAsF4BEf1hiwkPXa9ive/_ssgManifest.js",
    "static/0MAsF4BEf1hiwkPXa9ive/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/431bw722fec3m.js",
    "static/chunks/0if-vqkhyn-zc.js",
    "static/chunks/26swit4g4lpuz.js",
    "static/chunks/1vgpv7vwitdbl.js",
    "static/chunks/turbopack-40p2_tyb5oeom.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
