module.exports=[121425,e=>e.a(async(a,t)=>{try{var c=await e.y("next/dist/compiled/@vercel/og/index.node.js");e.n(c),t()}catch(e){t(e)}},!0)];

//# sourceMappingURL=%5Bexternals%5D_next_dist_compiled_%40vercel_og_index_node_01np1ap.js.map