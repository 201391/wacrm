module.exports=[982250,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bslug%5D_route_actions_15yw21j.js.map