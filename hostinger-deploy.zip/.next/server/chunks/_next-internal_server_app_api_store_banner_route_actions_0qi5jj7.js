module.exports=[817041,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_store_banner_route_actions_0qi5jj7.js.map