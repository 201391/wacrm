module.exports=[760755,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_products_page_actions_0n_mlzs.js.map