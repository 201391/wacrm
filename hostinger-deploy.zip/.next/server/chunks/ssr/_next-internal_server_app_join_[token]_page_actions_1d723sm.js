module.exports=[440758,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_join_%5Btoken%5D_page_actions_1d723sm.js.map