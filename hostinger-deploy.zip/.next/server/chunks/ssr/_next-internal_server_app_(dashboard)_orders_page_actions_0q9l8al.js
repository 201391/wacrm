module.exports=[323892,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_orders_page_actions_0q9l8al.js.map