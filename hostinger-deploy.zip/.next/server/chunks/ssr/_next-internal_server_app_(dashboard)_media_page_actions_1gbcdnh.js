module.exports=[868923,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_media_page_actions_1gbcdnh.js.map