module.exports=[282962,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_notifications_page_actions_006ifxy.js.map