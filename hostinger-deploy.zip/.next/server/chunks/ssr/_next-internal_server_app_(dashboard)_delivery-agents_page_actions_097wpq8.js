module.exports=[596687,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_delivery-agents_page_actions_097wpq8.js.map