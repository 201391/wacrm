module.exports=[177688,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_broadcasts_new_page_actions_12kcp2e.js.map