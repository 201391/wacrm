module.exports=[756993,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_automations_%5Bid%5D_logs_page_actions_0niko6c.js.map