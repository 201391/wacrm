module.exports=[132897,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_forgot-password_page_actions_14f7ecu.js.map