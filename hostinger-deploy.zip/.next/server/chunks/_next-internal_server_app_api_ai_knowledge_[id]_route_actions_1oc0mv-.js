module.exports=[623754,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ai_knowledge_%5Bid%5D_route_actions_1oc0mv-.js.map