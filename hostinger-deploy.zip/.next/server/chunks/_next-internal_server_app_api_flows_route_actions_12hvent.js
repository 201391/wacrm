module.exports=[24485,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_flows_route_actions_12hvent.js.map