module.exports=[767080,E=>{"use strict";let D=["DRAFT","PENDING","APPROVED","REJECTED","PAUSED","DISABLED","IN_APPEAL","PENDING_DELETION"];E.s(["normalizeStatus",0,function(E){let N=(E??"").toUpperCase();return"PENDING_REVIEW"===N?"PENDING":D.includes(N)?N:"PENDING"}])}];

//# sourceMappingURL=src_lib_whatsapp_template-status-normalize_ts_1r-8jad._.js.map