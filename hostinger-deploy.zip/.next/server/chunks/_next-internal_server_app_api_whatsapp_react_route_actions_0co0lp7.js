module.exports=[959672,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_whatsapp_react_route_actions_0co0lp7.js.map