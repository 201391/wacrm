globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/6V9jf44GQC4vR0vOaB9wl/_buildManifest.js",
    "static/6V9jf44GQC4vR0vOaB9wl/_ssgManifest.js",
    "static/6V9jf44GQC4vR0vOaB9wl/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3ivcc6t1s04dh.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/2yujvq-6xiuuw.js",
    "static/chunks/302ixioiwu4p5.js",
    "static/chunks/turbopack-3d7zv3qslkv7s.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
