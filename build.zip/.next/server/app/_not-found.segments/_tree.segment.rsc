:HL["/_next/static/chunks/2wri4kji0rkkb.css","style"]
:HL["/_next/static/chunks/03h3o36apj94v.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"6V9jf44GQC4vR0vOaB9wl"}
