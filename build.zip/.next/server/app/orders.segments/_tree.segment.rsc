:HL["/_next/static/chunks/2wri4kji0rkkb.css","style"]
:HL["/_next/static/chunks/03h3o36apj94v.css","style"]
:HL["/_next/static/media/83afe278b6a6bb3c-s.p.2bn3s6zvc0dyp.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"(dashboard)","param":null,"prefetchHints":4160,"slots":{"children":{"name":"orders","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}},"staleTime":300,"buildId":"6V9jf44GQC4vR0vOaB9wl"}
