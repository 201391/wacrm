var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[externals]__0l8ei7u._.js")
R.c("server/chunks/_0hrq3rk._.js")
R.c("server/chunks/[root-of-the-server]__00_hq9v._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_0p172-8._.js")
R.c("server/chunks/_next-internal_server_app_auth_callback_route_actions_0gq6cy0.js")
R.m(79799)
module.exports=R.m(79799).exports
