var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon/route.js")
R.c("server/chunks/[externals]__01qd7t7._.js")
R.c("server/chunks/_0h8dmj_._.js")
R.c("server/chunks/[root-of-the-server]__00_hq9v._.js")
R.c("server/chunks/node_modules_next_1zdbrne._.js")
R.c("server/chunks/_next-internal_server_app_icon_route_actions_02gqvdz.js")
R.m(58338)
module.exports=R.m(58338).exports
