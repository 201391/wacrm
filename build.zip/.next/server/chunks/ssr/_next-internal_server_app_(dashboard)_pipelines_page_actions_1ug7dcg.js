module.exports=[37754,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_pipelines_page_actions_1ug7dcg.js.map