module.exports=[10140,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_broadcasts_page_actions_1npvjp_.js.map