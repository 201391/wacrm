module.exports=[91126,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28dashboard%29_broadcasts_%5Bid%5D_page_actions_1ol9ro2.js.map