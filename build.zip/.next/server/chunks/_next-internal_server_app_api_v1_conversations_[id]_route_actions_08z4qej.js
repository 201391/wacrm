module.exports=[95575,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_v1_conversations_%5Bid%5D_route_actions_08z4qej.js.map